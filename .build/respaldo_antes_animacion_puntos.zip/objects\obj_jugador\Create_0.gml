/// @DnDAction : YoYo Games.Common.Variable
/// @DnDVersion : 1
/// @DnDHash : 879492E8
/// @DnDArgument : "var" "impactos"
/// @DnDArgument : "expr" "0"
/// @DnDArgument : "expr_relative" "0"
impactos = 0;
