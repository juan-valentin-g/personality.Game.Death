/// @DnDAction : YoYo Games.Movement.Set_Speed
/// @DnDVersion : 1
/// @DnDHash : 37A596E6
/// @DnDArgument : "speed" "-0.8"
/// @DnDArgument : "type" "1"
hspeed = -0.8;

/// @DnDAction : YoYo Games.Instances.Set_Alarm
/// @DnDVersion : 1
/// @DnDHash : 1101C4E9
/// @DnDArgument : "steps" "120"
alarm_set(0, 120);